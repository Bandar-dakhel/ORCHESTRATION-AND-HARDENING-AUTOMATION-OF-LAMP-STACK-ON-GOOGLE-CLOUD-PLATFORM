#!/bin/sh
sudo apt-get -y install python
sudo apt-get -y update
sudo apt-get -y install python-pip python-dev build-essential
sudo apt-get -y update
sudo pip install --upgrade pip
pip install --upgrade virtualenv
sudo apt-get -y install software-properties-common
sudo apt-add-repository ppa:ansible/ansible -y
sudo apt-get -y update
sudo apt-get -y install ansible
sudo pip install apache-libcloud
